<?php 
	ob_start();
	session_start();  

	if(empty($_SESSION['inventoryUserquantity']) || !isset($_SESSION['inventoryUserquantity'])){

			header("location: index.php");
	}


	if (isset($_POST['submit'])) {

		$conn = new mysqli("localhost", "root","", "inventory");


		$item_id = $_POST['item_id'];
		$items_name = $_POST['items_name'];
		$amount = $_POST['amount'];
		$quantity = $_POST['crate_quantity'];
		$date = date('Y-m-d/l/h:i:sa');
    		
    		$price = ($_POST['amount'] /$_POST['crate_quantity']);


		$sql = "INSERT INTO `items`( `item_id`, `items_name`, `price`, `crate_quantity`, `amount`, `date`) VALUES ('$item_id', '$items_name', '$price', '$quantity', '$amount', '$date') ";
		

		if ($conn->query($sql) == TRUE) {
			header("location: ../new-item.php?msg=Product Added Sucessfully");
		}else{
			header("location: ../new-item.php?msg=Unable to Add product".$conn->error);
		}
		
	}else{
		header("location: dashboard.php");
	}
?>