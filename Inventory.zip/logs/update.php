<?php
	/*ob_start();
	session_start();  

	if(empty($_SESSION['inventoryUserquantity']) || !isset($_SESSION['inventoryUserquantity'])){
utdown
			header("location: index.php");
	}*/

	if(isset($_GET['quantity'])){
		$conn = new mysqli("localhost", "root","", "inventory");	
		/*$quantity = $_GET['quantity'];
		$amount = $_GET['amount'];
		$crate_quantity = $_GET['crate_quantity'];*/
		$item = $_GET['item'];
		$page = $_GET['page'];

		$current = $conn->query("SELECT * FROM stock where items_name='$item'");	
    		$rows = $current->fetch_assoc();
    		$id = $rows['id'];

    		// get the values and calculate for the current stock
    		if($page === "stock"){
    		$quant = ($_GET['quantity'] + $rows['quantity']);
    		$crate_quant = ($_GET['crate_quantity'] + $rows['crate_quantity']);
    		$amt = ($_GET['amount'] + $rows['amount']);
    		
    		}else{
   			$quant = ($rows['quantity'] -$_GET['quantity']);
    		$crate_quant = ($rows['crate_quantity'] -$_GET['crate_quantity']);
    		$amt = ($rows['amount'] -$_GET['amount']);
    		
    		}/*
    		echo "$quant, $crate_quant, $amt";
    		echo "".$rows['quantity']." ".$rows['crate_quantity']."";
    		*/
    		//update stock of item to be sold

			$sql = $conn->query("UPDATE `stock` SET `quantity`='$quant',`crate_quantity`='$crate_quant',`amount`='$amt' WHERE id='$id'");
			//$update = "UPDATE stock SET `quantity`=\'$quant\',`crate_quantity`=\'$crate_quant\',`amount`=\'$amt\' WHERE id=\'$id\'";
			
    		if ($sql == TRUE) {
				header("location: ../new-$page.php?msg=$page Added Sucessfully");
    		}else{
			header("location: ../new-$page.php?msg=Unable to Added $page".$conn->error);
			}
			
	}	else{
		header("location: dashboard.php");
	}
?>