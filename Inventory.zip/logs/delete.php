<?php 
	ob_start();
	session_start();  

	if(empty($_SESSION['inventoryUserEmail']) || !isset($_SESSION['inventoryUserEmail'])){

			header("location: index.php");
	}

	if (isset($_GET['id'])) {
		
		$id = $_GET['id'];
		$conn = new mysqli("localhost", "root", "", "inventory");

		$sql = "DELETE FROM employees where employee_id = '$id' ";

		if ($conn->query($sql) == TRUE) {
			header("location: ../view-employee.php?msg=employee Deleted Successfully");
		}else{
			header("location: ../view-employee.php?msg=Unable to Delete employee");
		}


	} elseif (isset($_GET['id1'])) {
		
		$id1 = $_GET['id1'];
		$conn = new mysqli("localhost", "root", "", "inventory");

		$sql = "DELETE FROM items where item_id = '$id1' ";

		if ($conn->query($sql) == TRUE) {
			header("location: ../view-item.php?msg=item Deleted Successfully");
		}else{
			header("location: ../view-item.php?msg=Unable to Delete item");
		}


	} elseif (isset($_GET['id2'])) {
		
		$id2 = $_GET['id2'];
		$conn = new mysqli("localhost", "root", "", "inventory");

		$sql = "DELETE FROM stock where stock_id = '$id2' ";

		if ($conn->query($sql) == TRUE) {
			header("location: ../view-stock.php?msg=stock Deleted Successfully");
		}else{
			header("location: ../view-stock.php?msg=Unable to Delete stock");
		}


	} elseif (isset($_GET['id3'])) {
		
		$id3 = $_GET['id3'];
		$conn = new mysqli("localhost", "root", "", "inventory");

		$sql = "DELETE FROM supply where supply_id = '$id3' ";

		if ($conn->query($sql) == TRUE) {
			header("location: ../view-supply.php?msg=supply Deleted Successfully");
		}else{
			header("location: ../view-supply.php?msg=Unable to Delete supply");
		}


	}else{
		header("location: index.php");
	}


?>