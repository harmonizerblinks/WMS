<?php 
	ob_start();
	session_start();  

	if(empty($_SESSION['inventoryUserquantity']) || !isset($_SESSION['inventoryUserquantity'])){

			header("location: index.php");
	}


	if (isset($_POST['submit'])) {

		$conn = new mysqli("localhost", "root","", "inventory");

		$sales_id = $_POST['sales_id'];
		$cust_phone = $_POST['phone'];
		$items_name = $_POST['items_name'];
		$crate_quantity = $_POST['noc'];
		$date = date('Y-m-d/l/h:i:sa');

		$check = $conn->query("SELECT * FROM items where items_name='$items_name'");
		if ($check->num_rows > 0 ){
			$row = $check->fetch_assoc();    		
    		$amount = ($_POST['noc'] *$row['amount']);
    		$quantity = ($_POST['noc'] *$row['crate_quantity']);
    		$price = ($row['amount']);

    	$current = $conn->query("SELECT * FROM stock where items_name='$items_name'");
    	if ($current->num_rows > 0 ){
    	$rows = $current->fetch_assoc();
    		// get the values and calculate for the current sales
    		$quant = ($rows['quantity']);
    		//check if current stock meet the sales demand
    	if ($quant > $quantity){
    		//insert into sales table if sales not found
		$sql = "INSERT INTO `sales`(`sales_id`,`cust_phone`,`items_name`,`price`,`quantity`,`crate_quantity`,`total_amount`,`date`) VALUES ('$sales_id','$cust_phone','$items_name','$price','$quantity','$crate_quantity','$amount','$date') ";		

			if ($conn->query($sql) == TRUE) {
				header("location: update.php?page=sales&quantity=$quantity&amount=$amount&crate_quantity=$crate_quantity&item=$items_name");
			}else{
				header("location: ../new-sales.php?msg=Unable to Add sales".$conn->error);
			}
		}else{
				header("location: ../new-sales.php?msg=Not Enough Quantity in stock".$conn->error);
		}
	}else{
				header("location: ../new-sales.php?msg=Not in stock".$conn->error);
		}

	}else{
		header("location: ../new-sales.php?msg=Product Not yet added");
	}

	}else{
		header("location: dashboard.php");
	}

?>